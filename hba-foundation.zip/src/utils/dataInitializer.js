const initializeData = async () => {
  console.log('Data initialization skipped (development mode)');
  return Promise.resolve();
};

module.exports = {
  initializeData
}; 